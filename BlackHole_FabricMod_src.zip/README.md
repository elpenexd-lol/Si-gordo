# Black Hole (Fabric 1.21.11)

Compilar (necesitas JDK 21):
    gradle wrapper --gradle-version 9.2.1     # solo la primera vez (o abre la carpeta con IntelliJ)
    ./gradlew build                           # en Windows: gradlew.bat build
El .jar queda en build/libs/blackhole-1.0.0.jar (no uses el -sources). Ponlo en mods/ junto con Fabric API.

Comandos (OP):  /blackhole start | stop | status
Config: config/blackhole.json (borra el archivo para regenerarlo con los valores nuevos: consumeRadiusMultiplier=2.0, visualMaxDistance=96, useWorldSpawn=true, spawnHeight=5)
