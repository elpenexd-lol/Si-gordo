package com.blackhole;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BlackHoleMod implements ModInitializer {
    public static final String MOD_ID = "blackhole";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        BHConfig.load();
        ShaderInstaller.install();

        ServerLifecycleEvents.SERVER_STARTED.register(BlackHoleManager::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(BlackHoleManager::save);
        ServerTickEvents.END_SERVER_TICK.register(BlackHoleManager::tick);

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("blackhole")
                .requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
                .then(Commands.literal("start").executes(ctx -> {
                    CommandSourceStack s = ctx.getSource();
                    BlackHoleManager.start(s.getServer(), s.getLevel(), s.getPosition());
                    s.sendSuccess(() -> Component.literal("Algo diminuto ha aparecido en el cielo... " + BlackHoleManager.status()), true);
                    return 1;
                }))
                .then(Commands.literal("stop").executes(ctx -> {
                    CommandSourceStack s = ctx.getSource();
                    BlackHoleManager.stop(s.getServer());
                    s.sendSuccess(() -> Component.literal("El agujero negro se ha desvanecido."), true);
                    return 1;
                }))
                .then(Commands.literal("status").executes(ctx -> {
                    String msg = BlackHoleManager.status();
                    ctx.getSource().sendSuccess(() -> Component.literal(msg), false);
                    return 1;
                }))
            ));
    }
}
