package com.blackhole;

import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Copia el shader del cielo a shaderpacks/BlackHole_Sky.zip al iniciar el juego (solo cliente). */
public final class ShaderInstaller {
    private ShaderInstaller() {}

    public static void install() {
        if (FabricLoader.getInstance().getEnvironmentType() != EnvType.CLIENT) return;
        try {
            Path dir = FabricLoader.getInstance().getGameDir().resolve("shaderpacks");
            Files.createDirectories(dir);
            Path out = dir.resolve("BlackHole_Sky.zip");
            try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(out))) {
                for (String name : new String[]{"composite.vsh", "composite.fsh"}) {
                    try (InputStream in = ShaderInstaller.class.getResourceAsStream("/shaderpack/" + name)) {
                        if (in == null) continue;
                        zip.putNextEntry(new ZipEntry("shaders/" + name));
                        in.transferTo(zip);
                        zip.closeEntry();
                    }
                }
            }
        } catch (Exception e) {
            BlackHoleMod.LOGGER.warn("No se pudo instalar el shader del cielo", e);
        }
    }
}
