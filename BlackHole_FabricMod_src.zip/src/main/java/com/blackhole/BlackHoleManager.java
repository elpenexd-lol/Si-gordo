package com.blackhole;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.LevelResource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.Vec3;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class BlackHoleManager {

    /** Estado persistente. */
    private static final class State {
        String dim;
        double x, y, z;
        long age; // ticks desde que nació
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String VISUAL_TAG = "bh_visual";
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    // 2 (enviar a clientes) | 16 (sin actualizar formas) | 32 (sin drops)
    private static final int FLAGS = 2 | 16 | 32;

    private static State state;
    private static ServerLevel level;
    private static final Map<Long, Double> lastRadius = new HashMap<>();
    private static final Set<Long> done = new HashSet<>();
    private static double spin = 0;

    private BlackHoleManager() {}

    // ------------------------------------------------------------------ API

    public static void start(MinecraftServer server, ServerLevel lvl, Vec3 pos) {
        stop(server);
        state = new State();
        state.dim = lvl.dimension().identifier().toString();
        state.x = Math.floor(pos.x) + 0.5;
        state.y = Math.floor(pos.y) + 0.5;
        state.z = Math.floor(pos.z) + 0.5;
        state.age = 0;
        level = lvl;
        lastRadius.clear();
        done.clear();
        level.setChunkForced((int) Math.floor(state.x) >> 4, (int) Math.floor(state.z) >> 4, true);
        spawnVisuals(server);
        updateVisuals(server, radius());
        save(server);
    }

    public static void stop(MinecraftServer server) {
        if (state != null && level != null) {
            run(server, "kill @e[tag=" + VISUAL_TAG + "]");
            level.setChunkForced((int) Math.floor(state.x) >> 4, (int) Math.floor(state.z) >> 4, false);
        }
        state = null;
        level = null;
        lastRadius.clear();
        done.clear();
        try {
            Files.deleteIfExists(file(server));
        } catch (Exception ignored) {}
    }

    public static String status() {
        if (state == null) return "No hay ningún agujero negro activo.";
        return String.format(Locale.ROOT, "Radio: %.2f bloques | Edad: %d s | Posición: %.0f %.0f %.0f",
            radius(), state.age / 20, state.x, state.y, state.z);
    }

    // ------------------------------------------------------------ persistence

    private static Path file(MinecraftServer server) {
        return server.getWorldPath(LevelResource.ROOT).resolve("blackhole.json");
    }

    public static void save(MinecraftServer server) {
        try {
            if (state != null) Files.writeString(file(server), GSON.toJson(state));
        } catch (Exception e) {
            BlackHoleMod.LOGGER.error("No se pudo guardar el estado", e);
        }
    }

    public static void load(MinecraftServer server) {
        try {
            Path p = file(server);
            if (!Files.exists(p)) return;
            State s = GSON.fromJson(Files.readString(p), State.class);
            if (s == null) return;
            for (ServerLevel l : server.getAllLevels()) {
                if (l.dimension().identifier().toString().equals(s.dim)) {
                    state = s;
                    level = l;
                    return;
                }
            }
        } catch (Exception e) {
            BlackHoleMod.LOGGER.error("No se pudo cargar el estado", e);
        }
    }

    // ------------------------------------------------------------------ math

    private static double radius() {
        BHConfig c = BHConfig.INSTANCE;
        double delay = c.delaySeconds * 20.0;
        double r = c.startRadius;
        if (state.age > delay) {
            double secs = (state.age - delay) / 20.0;
            double exp = Math.min(c.growthPerSecond * secs, 700.0); // evita overflow
            r = c.startRadius * Math.exp(exp);
        }
        return Math.min(r, c.maxRadius);
    }

    // ------------------------------------------------------------------ tick

    public static void tick(MinecraftServer server) {
        if (state == null || level == null) return;
        state.age++;
        double r = radius();

        if (state.age % 20 == 0) {
            updateVisuals(server, r);
            if (r >= BHConfig.INSTANCE.consumeFromRadius && state.age % 40 == 0) {
                run(server, String.format(Locale.ROOT,
                    "playsound minecraft:entity.warden.heartbeat ambient @a %.2f %.2f %.2f %.1f 0.5",
                    state.x, state.y, state.z, (float) Math.min(5.0 + r / 4.0, 1000.0)));
            }
        }
        if (state.age % 1200 == 0) save(server);

        affectEntities(r);
        if (r >= BHConfig.INSTANCE.consumeFromRadius) consumeBlocks(server, r);
    }

    // -------------------------------------------------------------- entities

    private static void affectEntities(double r) {
        Vec3 c = new Vec3(state.x, state.y, state.z);
        double pullRange = r * 2.0 + 24.0;
        double pullRange2 = pullRange * pullRange;
        double r2 = r * r;

        List<Entity> toDiscard = new ArrayList<>();
        List<ServerPlayer> toKill = new ArrayList<>();

        for (Entity e : level.getAllEntities()) {
            if (e.getTags().contains(VISUAL_TAG)) continue;
            Vec3 d = c.subtract(e.position());
            double dist2 = d.lengthSqr();
            if (dist2 > pullRange2) continue;

            boolean immune = e instanceof ServerPlayer p && (p.isCreative() || p.isSpectator());

            if (dist2 <= r2 + 0.25) {
                if (e instanceof ServerPlayer p) {
                    if (!immune) toKill.add(p);
                } else {
                    toDiscard.add(e);
                }
                continue;
            }
            if (immune) continue;

            double dist = Math.sqrt(dist2);
            double strength = Math.min(0.35, 0.04 + 2.0 / Math.max(dist, 1.0));
            Vec3 push = d.scale(strength / dist);
            e.setDeltaMovement(e.getDeltaMovement().add(push));
            e.hurtMarked = true;
        }
        for (Entity e : toDiscard) e.discard();
        for (ServerPlayer p : toKill) {
            p.hurtServer(level, level.damageSources().genericKill(), Float.MAX_VALUE);
        }
    }

    // ---------------------------------------------------------------- blocks

    private static long key(int cx, int cz) {
        return ((long) cx << 32) ^ (cz & 0xffffffffL);
    }

    private record Candidate(LevelChunk chunk, long key, double nearest2, boolean inside) {}

    private static void consumeBlocks(MinecraftServer server, double r) {
        long deadline = System.nanoTime() + (long) (BHConfig.INSTANCE.consumeBudgetMs * 1_000_000.0);
        int vd = server.getPlayerList().getViewDistance() + 1;
        double r2 = r * r;
        double minY = level.getMinY();
        double maxY = level.getMaxY() + 1;

        Set<Long> seen = new HashSet<>();
        List<Candidate> list = new ArrayList<>();

        for (ServerPlayer p : level.players()) {
            int pcx = p.blockPosition().getX() >> 4;
            int pcz = p.blockPosition().getZ() >> 4;
            for (int cx = pcx - vd; cx <= pcx + vd; cx++) {
                for (int cz = pcz - vd; cz <= pcz + vd; cz++) {
                    long k = key(cx, cz);
                    if (!seen.add(k) || done.contains(k)) continue;

                    double x0 = cx * 16.0, x1 = x0 + 16.0, z0 = cz * 16.0, z1 = z0 + 16.0;
                    double nx = clamp(state.x, x0, x1) - state.x;
                    double ny = clamp(state.y, minY, maxY) - state.y;
                    double nz = clamp(state.z, z0, z1) - state.z;
                    double near2 = nx * nx + ny * ny + nz * nz;
                    if (near2 > r2) continue;

                    double fx = Math.max(Math.abs(state.x - x0), Math.abs(state.x - x1));
                    double fy = Math.max(Math.abs(state.y - minY), Math.abs(state.y - maxY));
                    double fz = Math.max(Math.abs(state.z - z0), Math.abs(state.z - z1));
                    boolean inside = fx * fx + fy * fy + fz * fz <= r2;

                    Double prev = lastRadius.get(k);
                    if (!inside && prev != null && r - prev < 1.0) continue;

                    LevelChunk chunk = level.getChunkSource().getChunkNow(cx, cz);
                    if (chunk == null) continue;
                    list.add(new Candidate(chunk, k, near2, inside));
                }
            }
        }
        if (list.isEmpty()) return;
        list.sort(Comparator.comparingDouble(Candidate::nearest2));

        for (Candidate c : list) {
            Double prev = lastRadius.get(c.key());
            processChunk(c.chunk(), r, prev == null ? 0.0 : prev);
            lastRadius.put(c.key(), r);
            if (c.inside()) {
                done.add(c.key());
                lastRadius.remove(c.key());
            }
            if (System.nanoTime() > deadline) break;
        }
    }

    private static void processChunk(LevelChunk chunk, double r, double prevR) {
        double r2 = r * r;
        int baseX = chunk.getPos().getMinBlockX();
        int baseZ = chunk.getPos().getMinBlockZ();
        int minSectionY = level.getMinY() >> 4;
        LevelChunkSection[] sections = chunk.getSections();
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection sec = sections[i];
            if (sec == null || sec.hasOnlyAir()) continue;
            int baseY = (minSectionY + i) << 4;
            if (Math.abs(state.y - clamp(state.y, baseY, baseY + 16)) > r) continue;

            for (int lx = 0; lx < 16; lx++) {
                double dx = baseX + lx + 0.5 - state.x;
                double dx2 = dx * dx;
                if (dx2 > r2) continue;
                for (int lz = 0; lz < 16; lz++) {
                    double dz = baseZ + lz + 0.5 - state.z;
                    double rem = r2 - dx2 - dz * dz;
                    if (rem < 0) continue;
                    double half = Math.sqrt(rem);
                    int yFrom = Math.max(baseY, (int) Math.ceil(state.y - half - 0.5));
                    int yTo = Math.min(baseY + 15, (int) Math.floor(state.y + half - 0.5));
                    for (int wy = yFrom; wy <= yTo; wy++) {
                        BlockState bs = sec.getBlockState(lx, wy & 15, lz);
                        if (bs.isAir()) continue;
                        pos.set(baseX + lx, wy, baseZ + lz);
                        level.setBlock(pos, AIR, FLAGS);
                    }
                }
            }
        }
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    // --------------------------------------------------------------- visuals

    private static void run(MinecraftServer server, String cmd) {
        if (level == null) return;
        CommandSourceStack src = server.createCommandSourceStack().withLevel(level).withSuppressedOutput();
        server.getCommands().performPrefixedCommand(src, cmd);
    }

    private static String f(double v) {
        return String.format(Locale.ROOT, "%.5ff", v);
    }

    private static String transform(double scale, double tz, double yaw) {
        double s = Math.sin(yaw / 2), c = Math.cos(yaw / 2);
        return "transformation:{left_rotation:[0f," + f(s) + "," + "0f," + f(c) + "],"
            + "right_rotation:[0f,0f,0f,1f],translation:[0f,0f," + f(tz) + "],"
            + "scale:[" + f(scale) + "," + f(scale) + "," + f(scale) + "]}";
    }

    private static void spawnVisuals(MinecraftServer server) {
        String[][] parts = {{"horizon", "center"}, {"halo", "center"}, {"disc", "fixed"}};
        for (String[] p : parts) {
            run(server, String.format(Locale.ROOT,
                "summon minecraft:item_display %.3f %.3f %.3f {Tags:[\"%s\",\"bh_%s\"],billboard:\"%s\","
                    + "brightness:{sky:15,block:15},item_display:\"none\",Invulnerable:1b,"
                    + "item:{id:\"minecraft:stone\",count:1,components:{\"minecraft:item_model\":\"blackhole:%s\"}}}",
                state.x, state.y, state.z, VISUAL_TAG, p[0], p[1], p[0]));
        }
    }

    private static void updateVisuals(MinecraftServer server, double r) {
        spin += 0.5;
        double view = Math.max(1.0, (r * 8.0) / 64.0);
        String common = ",start_interpolation:0,interpolation_duration:21,view_range:" + f(view);

        // horizonte: círculo negro, mira siempre a la cámara
        run(server, "data merge entity @e[type=minecraft:item_display,tag=bh_horizon,limit=1] {"
            + transform(2.0 * r, 0, 0) + ",width:" + f(2.0 * r) + ",height:" + f(2.0 * r) + common + "}");
        // halo: brillo del anillo de fotones, un poco detrás del horizonte
        run(server, "data merge entity @e[type=minecraft:item_display,tag=bh_halo,limit=1] {"
            + transform(2.7 * r, -0.05 * r, 0) + ",width:" + f(2.7 * r) + ",height:" + f(2.7 * r) + common + "}");
        // disco de acreción: horizontal y girando
        run(server, "data merge entity @e[type=minecraft:item_display,tag=bh_disc,limit=1] {"
            + transform(8.0 * r, 0, spin) + ",width:" + f(8.0 * r) + ",height:" + f(8.0 * r) + common + "}");
    }
}
