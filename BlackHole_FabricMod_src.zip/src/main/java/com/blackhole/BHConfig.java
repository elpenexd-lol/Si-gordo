package com.blackhole;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Config en config/blackhole.json */
public final class BHConfig {
    /** Segundos que permanece diminuto y sin consumir nada. */
    public double delaySeconds = 60.0;
    /** Radio inicial en bloques (0.15 = huevo pequeño). */
    public double startRadius = 0.15;
    /** Crecimiento exponencial por segundo (0.025 = x2 cada ~28 s). */
    public double growthPerSecond = 0.025;
    /** Radio máximo en bloques (prácticamente ilimitado). */
    public double maxRadius = 30_000_000.0;
    /** Milisegundos por tick que se pueden gastar borrando bloques. */
    public double consumeBudgetMs = 30.0;
    /** Radio mínimo (bloques) a partir del cual empieza a consumir. */
    public double consumeFromRadius = 0.3;
    /** Altura sobre el jugador a la que nace el agujero negro (solo si useWorldSpawn = false). */
    public double skyHeight = 150.0;
    /** Si es true, el agujero negro nace sobre el spawn del mundo en vez de sobre quien ejecuta el comando. */
    public boolean useWorldSpawn = true;
    /** Bloques por encima del spawn del mundo a los que nace (con useWorldSpawn = true). */
    public double spawnHeight = 5.0;
    /** Segundos que tarda el cielo en pasar de atardecer a medianoche al empezar a crecer. */
    public double darkenSeconds = 45.0;
    /** Radio de destrucción = radio del agujero x este número (esfera centrada en el agujero; crece con él). */
    public double consumeRadiusMultiplier = 2.0;
    /** El radio de atracción de entidades = radio x este número + pullExtraBlocks (más pequeño). */
    public double pullRadiusMultiplier = 1.3;
    public double pullExtraBlocks = 12.0;
    /** Distancia máxima (bloques) a la que se dibuja el agujero "de verdad". Más lejos se proyecta en esa dirección con el tamaño aparente correcto, así se ve desde cualquier distancia. */
    public double visualMaxDistance = 96.0;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static BHConfig INSTANCE = new BHConfig();

    public static void load() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("blackhole.json");
        try {
            if (Files.exists(p)) {
                INSTANCE = GSON.fromJson(Files.readString(p), BHConfig.class);
                if (INSTANCE == null) INSTANCE = new BHConfig();
            }
            Files.writeString(p, GSON.toJson(INSTANCE));
        } catch (Exception e) {
            BlackHoleMod.LOGGER.error("No se pudo leer/escribir blackhole.json", e);
        }
    }
}
