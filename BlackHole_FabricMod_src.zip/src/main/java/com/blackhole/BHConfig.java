package com.blackhole;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Config en config/blackhole.json */
public final class BHConfig {
    /** Segundos que permanece diminuto y sin consumir nada. */
    public double delaySeconds = 60.0;
    /** Radio inicial en bloques (0.15 = huevo pequeño). */
    public double startRadius = 0.15;
    /** Crecimiento exponencial por segundo (0.025 = x2 cada ~28 s). */
    public double growthPerSecond = 0.025;
    /** Radio máximo en bloques (prácticamente ilimitado). */
    public double maxRadius = 30_000_000.0;
    /** Milisegundos por tick que se pueden gastar borrando bloques. */
    public double consumeBudgetMs = 30.0;
    /** Radio mínimo (bloques) a partir del cual empieza a consumir. */
    public double consumeFromRadius = 1.0;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static BHConfig INSTANCE = new BHConfig();

    public static void load() {
        Path p = FabricLoader.getInstance().getConfigDir().resolve("blackhole.json");
        try {
            if (Files.exists(p)) {
                INSTANCE = GSON.fromJson(Files.readString(p), BHConfig.class);
                if (INSTANCE == null) INSTANCE = new BHConfig();
            }
            Files.writeString(p, GSON.toJson(INSTANCE));
        } catch (Exception e) {
            BlackHoleMod.LOGGER.error("No se pudo leer/escribir blackhole.json", e);
        }
    }
}
