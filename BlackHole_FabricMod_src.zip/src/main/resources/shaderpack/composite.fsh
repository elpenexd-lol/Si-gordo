#version 330 compatibility
// Cielo estrellado (basado en tu shader de Shadertoy), optimizado.
// Noche: fondo oscuro normal. Día: el fondo se tiñe un poco de azul y las estrellas son más tenues.

// ---- AJUSTES ----
#define NUM_LAYERS 4          // capas de estrellas (antes 8). Menos = menos lag
#define STAR_OPACITY_NIGHT 0.55   // opacidad de las estrellas de noche
#define STAR_OPACITY_DAY   0.25   // opacidad de las estrellas de día
#define DAY_BLUE 0.55         // cuánto azul se añade al fondo de día (0 = nada)
// -----------------

#define TAU 6.28318
#define Velocity .025
#define CanvasView 20.

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float frameTimeCounter;

in vec2 texcoord;
/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

float Hash21(vec2 p){
    p = fract(p*vec2(123.34, 456.21));
    p += dot(p, p+45.32);
    return fract(p.x*p.y);
}

// una estrella (brillo + destello en cruz), sin sin() constante
float Star(vec2 uv, float flare){
    float d = length(uv);
    float m = 0.03/d;
    float rays = max(0., .5-abs(uv.x*uv.y*1000.));
    m += rays*flare*2.;
    m *= smoothstep(1., .1, d);
    return m;
}

vec3 StarLayer(vec2 uv, float time){
    vec3 col = vec3(0);
    vec2 gv = fract(uv);
    vec2 id = floor(uv);
    for(int y=-1;y<=1;y++){
        for(int x=-1; x<=1; x++){
            vec2 offs = vec2(x,y);
            float n = Hash21(id+offs);
            float size = fract(n);
            // las estrellas muy pequeñas casi no aportan: se saltan
            if (size < 0.08) continue;
            float star = Star(gv-offs-vec2(n, fract(n*34.))+.5, smoothstep(.1,.9,size)*.46);
            // color barato (mezcla entre azul y rosa) en vez de 3 sin()
            vec3 color = mix(vec3(.75,.8,1.0), vec3(1.0,.65,.95), fract(n*2345.2));
            color *= vec3(.9,.59,.9+size);
            star *= sin(time*.6+n*TAU)*.5+.5;
            col += star*size*color;
        }
    }
    return col;
}

void main() {
    vec4 sceneFull = texture(colortex0, texcoord);
    vec3 scene = sceneFull.rgb;

    // Cielo = donde la profundidad (con y sin translúcidos) está en el infinito.
    float depth = min(texture(depthtex0, texcoord).r, texture(depthtex1, texcoord).r);
    if (depth < 0.99999) { outColor = sceneFull; return; }

    // dirección del rayo en el mundo
    vec4 v = gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
    vec3 rd = normalize(mat3(gbufferModelViewInverse) * normalize(v.xyz / v.w));

    // 0 de día, 1 de noche (según la altura del sol)
    vec3 sunDir = normalize(mat3(gbufferModelViewInverse) * normalize(sunPosition));
    float night = smoothstep(0.0, -0.3, sunDir.y);

    // el cielo se queda fijo en el mundo y se mueve con la cámara
    vec2 uv = vec2(atan(rd.x, rd.z), asin(clamp(rd.y, -1.0, 1.0))) / 1.2;
    float t = frameTimeCounter * Velocity;
    float time = frameTimeCounter;

    vec3 col = vec3(0);
    for(int k=0; k<NUM_LAYERS; k++){
        float i = float(k) / float(NUM_LAYERS);
        float depthL = fract(i+t);
        float scale = mix(CanvasView, .5, depthL);
        float fade = depthL*smoothstep(1.,.9,depthL);
        if (fade < 0.01) continue;
        col += StarLayer(uv*scale+i*453.2-time*.05, time)*fade;
    }
    // con menos capas, compensa el brillo para no perder densidad
    col *= 8.0 / float(NUM_LAYERS) * 0.6;

    // fondo: noche = oscuro normal; día = tu cielo, un poco más azul
    vec3 bgNight = scene * 0.12;
    vec3 bgDay = mix(scene, scene * vec3(0.70, 0.90, 1.30) + vec3(0.0, 0.03, 0.10), DAY_BLUE);
    vec3 bg = mix(bgDay, bgNight, night);

    float starOpacity = mix(STAR_OPACITY_DAY, STAR_OPACITY_NIGHT, night);
    vec3 starTint = mix(vec3(0.75, 0.88, 1.0), vec3(1.0), night);
    vec3 sky = bg + min(col, vec3(3.0)) * starOpacity * starTint;

    outColor = vec4(sky, sceneFull.a);
}
