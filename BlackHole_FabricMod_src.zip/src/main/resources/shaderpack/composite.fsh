#version 330 compatibility
// Cielo estrellado (basado en tu shader de Shadertoy). Aparece cuando el cielo se oscurece.

#define NUM_LAYERS 8.
#define TAU 6.28318
#define PI 3.141592
#define Velocity .025
#define StarGlow 0.025
#define StarSize 2.
#define CanvasView 20.

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform float frameTimeCounter;

in vec2 texcoord;
/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;

float Star(vec2 uv, float flare){
    float d = length(uv);
    float m = sin(StarGlow*1.2)/d;
    float rays = max(0., .5-abs(uv.x*uv.y*1000.));
    m += (rays*flare)*2.;
    m *= smoothstep(1., .1, d);
    return m;
}

float Hash21(vec2 p){
    p = fract(p*vec2(123.34, 456.21));
    p += dot(p, p+45.32);
    return fract(p.x*p.y);
}

vec3 StarLayer(vec2 uv){
    vec3 col = vec3(0);
    vec2 gv = fract(uv);
    vec2 id = floor(uv);
    for(int y=-1;y<=1;y++){
        for(int x=-1; x<=1; x++){
            vec2 offs = vec2(x,y);
            float n = Hash21(id+offs);
            float size = fract(n);
            float star = Star(gv-offs-vec2(n, fract(n*34.))+.5, smoothstep(.1,.9,size)*.46);
            vec3 color = sin(vec3(.2,.3,.9)*fract(n*2345.2)*TAU)*.25+.75;
            color = color*vec3(.9,.59,.9+size);
            star *= sin(frameTimeCounter*.6+n*TAU)*.5+.5;
            col += star*size*color;
        }
    }
    return col;
}

void main() {
    vec4 sceneFull = texture(colortex0, texcoord);
    vec3 scene = sceneFull.rgb;

    // Profundidad con translúcidos (0) y sin ellos (1): si CUALQUIERA de las dos
    // indica geometría (bloque, mob, mano, agua), NO es cielo.
    float d0 = texture(depthtex0, texcoord).r;
    float d1 = texture(depthtex1, texcoord).r;
    float depth = min(d0, d1);

    // dirección del rayo en el mundo
    vec4 v = gbufferProjectionInverse * vec4(texcoord * 2.0 - 1.0, 1.0, 1.0);
    vec3 rd = normalize(mat3(gbufferModelViewInverse) * normalize(v.xyz / v.w));

    // 0 de día, 1 de noche (según la altura del sol)
    vec3 sunDir = normalize(mat3(gbufferModelViewInverse) * normalize(sunPosition));
    float night = smoothstep(0.0, -0.3, sunDir.y);

    // Máscara de cielo: solo donde el búfer de profundidad está en el infinito.
    // Margen pequeño para evitar errores de precisión en profundidad de 24 bits.
    float skyMask = step(0.99999, depth);

    // Seguro extra: el cielo nocturno vanilla es casi negro. Si el píxel es claro
    // (bloque iluminado, mob, antorcha...) nunca se pisa con estrellas.
    float lum = dot(scene, vec3(0.3333));
    skyMask *= 1.0 - smoothstep(0.10, 0.30, lum);

    if (skyMask * night <= 0.001) { outColor = vec4(scene, sceneFull.a); return; }

    // el cielo se queda fijo en el mundo y se mueve con la cámara
    vec2 uv = vec2(atan(rd.x, rd.z), asin(clamp(rd.y, -1.0, 1.0))) / 1.2;
    float t = frameTimeCounter * Velocity;
    vec3 col = vec3(0);
    for(float i=0.; i<1.; i+=1./NUM_LAYERS){
        float depthL = fract(i+t);
        float scale = mix(CanvasView, .5, depthL);
        float fade = depthL*smoothstep(1.,.9,depthL);
        col += StarLayer(uv*scale+i*453.2-frameTimeCounter*.05)*fade;
    }

    vec3 sky = scene * 0.12 + min(col, vec3(3.0));
    outColor = vec4(mix(scene, sky, night * skyMask), sceneFull.a);
}
