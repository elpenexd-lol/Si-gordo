#version 330 compatibility
// Bloques, entidades (mobs), agua, mano: textura x color x lightmap vanilla.
uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform vec4 entityColor; // destello rojo al recibir daño
in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 outColor;
void main() {
    vec4 c = texture(gtexture, texcoord) * glcolor;
    if (c.a < 0.1) discard;
    c.rgb = mix(c.rgb, entityColor.rgb, entityColor.a);
    c.rgb *= texture(lightmap, lmcoord).rgb;
    outColor = c;
}
